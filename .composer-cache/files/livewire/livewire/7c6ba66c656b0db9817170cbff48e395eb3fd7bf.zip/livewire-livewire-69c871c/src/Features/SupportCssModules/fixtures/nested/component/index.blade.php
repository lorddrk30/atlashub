<?php

new class extends Livewire\Component {
    //
};
?>

<div>
    <div dusk="target" class="test-styled">styled</div>
</div>

<style>
    .test-styled {
        color: rgb(255, 0, 0);
    }
</style>
