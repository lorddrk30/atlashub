<div>
    <button wire:click="$js.test" dusk="test">Test</button>
</div>
