<?php

namespace Livewire\Attributes;

use Livewire\Features\SupportTransitions\BaseTransitionAttribute;

#[\Attribute(\Attribute::TARGET_METHOD)]
class Transition extends BaseTransitionAttribute
{
    //
}
