<?php

namespace Livewire\Attributes;

use Livewire\Features\SupportJson\BaseJson;

#[\Attribute(\Attribute::TARGET_METHOD)]
class Json extends BaseJson
{
    //
}
