<?php

namespace Livewire\Attributes;

use Livewire\Features\SupportAsync\BaseAsync;

#[\Attribute]
class Async extends BaseAsync
{
    //
}
