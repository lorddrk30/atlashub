<?php

return [

    'actions' => [

        'filter' => [
            'label' => 'តម្រង',
        ],

    ],

];
