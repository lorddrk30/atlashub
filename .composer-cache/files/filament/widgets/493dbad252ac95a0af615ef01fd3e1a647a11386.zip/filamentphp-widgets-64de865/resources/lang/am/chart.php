<?php

return [

    'actions' => [

        'filter' => [
            'label' => 'ማጣርያ',
        ],

    ],

];
