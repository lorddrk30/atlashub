<?php

return [

    'actions' => [

        'filter' => [
            'label' => 'Филтер',
        ],

    ],

];
