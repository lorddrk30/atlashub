<?php

return [

    'actions' => [

        'filter' => [
            'label' => 'Filtrer',
        ],

    ],

];
