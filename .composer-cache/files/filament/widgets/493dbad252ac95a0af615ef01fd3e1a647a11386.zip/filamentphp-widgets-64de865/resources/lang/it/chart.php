<?php

return [

    'actions' => [

        'filter' => [
            'label' => 'Filtra',
        ],

    ],

];
