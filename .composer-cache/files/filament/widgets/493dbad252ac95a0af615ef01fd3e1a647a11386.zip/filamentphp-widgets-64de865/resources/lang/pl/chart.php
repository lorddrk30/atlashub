<?php

return [

    'actions' => [

        'filter' => [
            'label' => 'Filtruj',
        ],

    ],

];
