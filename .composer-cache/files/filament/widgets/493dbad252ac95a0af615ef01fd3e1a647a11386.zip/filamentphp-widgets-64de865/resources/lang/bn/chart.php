<?php

return [

    'actions' => [

        'filter' => [
            'label' => 'ফিল্টার করুন',
        ],

    ],

];
