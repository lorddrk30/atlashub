<?php

namespace Filament\Infolists\View;

class InfolistsIconAlias
{
    const COMPONENTS_ICON_ENTRY_FALSE = 'infolists::components.icon-entry.false';

    const COMPONENTS_ICON_ENTRY_TRUE = 'infolists::components.icon-entry.true';
}
