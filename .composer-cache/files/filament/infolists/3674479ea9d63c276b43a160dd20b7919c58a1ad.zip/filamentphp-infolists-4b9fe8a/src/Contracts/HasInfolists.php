<?php

namespace Filament\Infolists\Contracts;

interface HasInfolists {}
