<?php

return [

    'entries' => [

        'text' => [

            'actions' => [
                'collapse_list' => ':count ခုကို ဖျောက်ထားသည်',
                'expand_list' => ':count ခုကို ပြသထားသည်',
            ],

            'more_list_items' => 'နောက်ထပ် :count ခု ကျန်ရှိသည်',

        ],

        'key_value' => [

            'columns' => [

                'key' => [
                    'label' => 'Key',
                ],

                'value' => [
                    'label' => 'တန်ဖိုး',
                ],

            ],

            'placeholder' => 'မှတ်တမ်းမရှိသေးပါ',

        ],

    ],

];
