<?php

return [

    'entries' => [

        'text' => [

            'actions' => [
                'collapse_list' => 'Прикажи :count помалку',
                'expand_list' => 'Прикажи :count повеќе',
            ],

            'more_list_items' => 'и :count повеќе',

        ],

        'key_value' => [

            'columns' => [

                'key' => [
                    'label' => 'Клуч',
                ],

                'value' => [
                    'label' => 'Вредност',
                ],

            ],

            'placeholder' => 'Нема записи',

        ],

    ],

];
