<?php

return [

    'entries' => [

        'text' => [

            'actions' => [
                'collapse_list' => 'Hiển thị giảm :count',
                'expand_list' => 'Hiển thị thêm :count',
            ],

            'more_list_items' => 'và thêm :count',

        ],

        'key_value' => [

            'columns' => [

                'key' => [
                    'label' => 'Khóa',
                ],

                'value' => [
                    'label' => 'Giá trị',
                ],

            ],

            'placeholder' => 'Không có mục nào',

        ],

    ],

];
