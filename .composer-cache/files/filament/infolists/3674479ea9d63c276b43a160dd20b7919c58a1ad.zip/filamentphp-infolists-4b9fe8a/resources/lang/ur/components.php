<?php

return [

    'entries' => [

        'text' => [

            'actions' => [
                'collapse_list' => ':count کم دکھائیں',
                'expand_list' => ':count مزید دکھائیں',
            ],

            'more_list_items' => 'اور :count مزید',

        ],

        'key_value' => [

            'columns' => [

                'key' => [
                    'label' => 'کلید',
                ],

                'value' => [
                    'label' => 'قدر',
                ],

            ],

            'placeholder' => 'کوئی اندراج نہیں',

        ],

    ],

];
