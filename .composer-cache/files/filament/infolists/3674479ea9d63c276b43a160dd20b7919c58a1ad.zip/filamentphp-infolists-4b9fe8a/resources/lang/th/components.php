<?php

return [

    'entries' => [

        'text' => [

            'actions' => [
                'collapse_list' => 'แสดงให้น้อยกว่านี้ :count รายการ',
                'expand_list' => 'แสดงอีก :count รายการ',
            ],

            'more_list_items' => 'และอีก :count รายการ',

        ],

        'key_value' => [

            'columns' => [

                'key' => [
                    'label' => 'คีย์',
                ],

                'value' => [
                    'label' => 'ค่า',
                ],

            ],

            'placeholder' => 'ไม่มีรายการ',

        ],

    ],

];
