<?php

return [

    'title' => 'چالاککردنی ئیمەیڵ',

    'heading' => 'چالاککردنی ئیمەیڵ',

    'actions' => [

        'resend_notification' => [
            'label' => 'دووبارە چالاککردن بنێرە',
        ],

    ],

    'messages' => [
        'notification_not_received' => 'ئیمەیڵەکەت پێ نەگەیشت بۆ چالاککردن؟',
        'notification_sent' => 'ئیمەیڵێکمان نارد بۆ :email کە ڕێنمایی چۆنیەتی چالاککردنی هەژمارەکەتی تێدایە.',
    ],

    'notifications' => [

        'notification_resent' => [
            'title' => 'چالاککردنی ئیمەیڵ دووبارە نێردرا.',
        ],

        'notification_resend_throttled' => [
            'title' => 'زۆر هەوڵ بۆ چالاککردن درا',
            'body' => 'تکایە دوای :seconds چرکە هەوڵ بدەرەوە.',
        ],

    ],

];
