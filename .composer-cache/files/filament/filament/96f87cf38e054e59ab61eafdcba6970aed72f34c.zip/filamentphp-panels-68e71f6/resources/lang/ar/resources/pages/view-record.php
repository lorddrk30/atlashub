<?php

return [

    'title' => 'عرض :label',

    'breadcrumb' => 'عرض',

    'navigation_label' => 'عرض',

    'content' => [

        'tab' => [
            'label' => 'عرض',
        ],

    ],

];
