<?php

return [

    'title' => 'Administrar :relationship :label',

];
