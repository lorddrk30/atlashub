<?php

return [

    'notifications' => [

        'email_changed' => [
            'title' => 'ইমেইল ঠিকানা পরিবর্তিত হয়েছে',
            'body' => 'আপনার ইমেইল ঠিকানা সফলভাবে পরিবর্তিত হয়েছে।',
        ],

    ],

];
