<?php

return [

    'title' => 'Gérer les :relationship de :label',

];
