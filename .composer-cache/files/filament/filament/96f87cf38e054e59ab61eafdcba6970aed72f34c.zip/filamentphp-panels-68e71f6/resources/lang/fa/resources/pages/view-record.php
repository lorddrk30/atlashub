<?php

return [

    'title' => 'مشاهده :label',

    'breadcrumb' => 'مشاهده',

    'navigation_label' => 'مشاهده',

    'content' => [

        'tab' => [
            'label' => 'مشاهده',
        ],

    ],

];
