<?php

return [

    'subject' => 'Hier ist Ihr Anmeldecode',

    'lines' => [
        'Ihr Anmeldecode lautet: :code',
        'Dieser Code läuft in einer Minute ab.|Dieser Code läuft in :minutes Minuten ab.',
    ],

];
