<?php

return [

    'notifications' => [

        'verified' => [
            'title' => 'Sähköposti vaihdettu',
            'body' => 'Sähköpostisi on onnistuneesti vaihdettu osoitteeseen :email.',
        ],

    ],

];
