<?php

return [

    'title' => 'ইমেইল যাচাই করুন',

    'heading' => 'আপনার ইমেইল ঠিকানা যাচাই করুন',

    'actions' => [

        'resend_notification' => [
            'label' => 'যাচাই ইমেইল আবার পাঠান',
        ],

    ],

    'notifications' => [

        'verification_link_sent' => [
            'title' => 'যাচাই লিংক পাঠানো হয়েছে',
            'body' => 'আপনার ইমেইল ঠিকানায় একটি নতুন যাচাই লিংক পাঠানো হয়েছে।',
        ],

    ],

];
