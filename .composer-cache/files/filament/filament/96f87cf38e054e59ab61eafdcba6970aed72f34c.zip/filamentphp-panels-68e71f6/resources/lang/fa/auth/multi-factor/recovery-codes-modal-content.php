<?php

return [

    'actions' => [

        'کلیک برای',

        'copy' => [
            'label' => 'کپی',
        ],

        'یا',

        'download' => [
            'label' => 'دانلود',
        ],

        'تمام کد به صورت یکجا.',

    ],

    'messages' => [
        'copied' => 'کپی شد',
    ],

];
