<?php

return [

    'title' => 'Error while loading page',

    'body' => 'There was an error while attempting to load this page. Please try again later.',

];
