<?php

return [

    'notifications' => [

        'blocked' => [
            'title' => 'Sähköpostin muutos estetty',
            'body' => 'Estit sähköpostin muutoksen osoitteeseen :email. Jos et tehnyt alkuperäistä pyyntöä, ota yhteyttä meihin heti.',
        ],

        'failed' => [
            'title' => 'Sähköpostin muutoksen esto epäonnistui',
            'body' => 'Valitettavasti et pystynyt peruuttamaan sähköpostin muutosta osoitteeseen :email, sillä se oli jo vahvistettu ennen kuin yritit estää sen. Jos et tehnyt alkuperäistä pyyntöä, ota yhteyttä meihin heti.',
        ],

    ],

];
