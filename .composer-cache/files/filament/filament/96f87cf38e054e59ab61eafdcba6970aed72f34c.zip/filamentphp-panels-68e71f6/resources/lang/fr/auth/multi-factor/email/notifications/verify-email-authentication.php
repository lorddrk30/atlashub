<?php

return [

    'subject' => 'Voici votre code de connexion',

    'lines' => [
        'Votre code de connexion est :code',
        'Ce code expirera dans une minute.|Ce code expirera dans :minutes minutes.',
    ],

];
