<?php

return [

    'subject' => 'Here\'s your sign-in code',

    'lines' => [
        'Your sign-in code is: :code',
        'This code will expire in a minute.|This code will expire in :minutes minutes.',
    ],

];
