<?php

return [

    'title' => 'Tableau de bord',

    'actions' => [

        'filter' => [

            'label' => 'Filtrer',

            'modal' => [

                'heading' => 'Filtrer',

                'actions' => [

                    'apply' => [

                        'label' => 'Appliquer',

                    ],

                ],

            ],

        ],

    ],

];
