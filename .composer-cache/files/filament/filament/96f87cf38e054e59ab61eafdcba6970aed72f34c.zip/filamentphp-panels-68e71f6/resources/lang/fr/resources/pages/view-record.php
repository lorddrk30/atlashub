<?php

return [

    'title' => 'Afficher :label',

    'breadcrumb' => 'Afficher',

    'navigation_label' => 'Afficher',

    'content' => [

        'tab' => [
            'label' => 'Afficher',
        ],

    ],

];
