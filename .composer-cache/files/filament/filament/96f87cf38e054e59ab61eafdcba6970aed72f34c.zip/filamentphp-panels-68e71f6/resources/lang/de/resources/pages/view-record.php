<?php

return [

    'title' => ':label ansehen',

    'breadcrumb' => 'Ansehen',

    'navigation_label' => 'Ansehen',

    'content' => [

        'tab' => [
            'label' => 'Ansehen',
        ],

    ],

];
