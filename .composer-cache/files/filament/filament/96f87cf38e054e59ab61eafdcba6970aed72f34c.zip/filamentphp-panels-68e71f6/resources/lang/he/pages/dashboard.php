<?php

return [

    'title' => 'בית',

];
