<?php

return [

    'actions' => [

        'أضغط لـ',

        'copy' => [
            'label' => 'نسخ',
        ],

        'أو',

        'download' => [
            'label' => 'تنزيل',
        ],

        'جميع الرموز دفعة واحدة.',

    ],

    'messages' => [
        'copied' => 'تم النسخ',
    ],

];
