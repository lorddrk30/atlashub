<?php

return [

    'label' => 'টেন্যান্ট প্রোফাইল',

    'form' => [

        'name' => [
            'label' => 'নাম',
        ],

        'actions' => [

            'save' => [
                'label' => 'সংরক্ষণ করুন',
            ],

        ],

    ],

    'notifications' => [

        'saved' => [
            'title' => 'সংরক্ষিত হয়েছে',
        ],

    ],

];
