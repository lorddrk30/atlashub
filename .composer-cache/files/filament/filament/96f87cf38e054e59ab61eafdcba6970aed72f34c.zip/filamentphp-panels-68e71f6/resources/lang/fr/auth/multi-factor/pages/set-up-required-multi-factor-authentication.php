<?php

return [

    'title' => 'Configurer l\'authentification à deux facteurs (2FA)',

    'heading' => 'Configurer l\'authentification à deux facteurs',

    'subheading' => '2FA ajoute une couche de sécurité supplémentaire à votre compte en nécessitant une deuxième forme de vérification lors de la connexion.',

    'actions' => [

        'continue' => [
            'label' => 'Continuer',
        ],

    ],

];
