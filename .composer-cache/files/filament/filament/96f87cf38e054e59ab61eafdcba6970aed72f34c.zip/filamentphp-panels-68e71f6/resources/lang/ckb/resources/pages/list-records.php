<?php

return [

    'breadcrumb' => 'تۆمارەکان',

];
