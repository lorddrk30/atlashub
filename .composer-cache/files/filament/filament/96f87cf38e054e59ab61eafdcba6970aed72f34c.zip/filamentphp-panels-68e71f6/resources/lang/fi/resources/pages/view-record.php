<?php

return [

    'title' => 'Näytä :label',

    'breadcrumb' => 'Näytä',

    'navigation_label' => 'Näytä',

    'content' => [

        'tab' => [
            'label' => 'Näytä',
        ],

    ],

];
