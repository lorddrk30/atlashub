<?php

return [

    'notifications' => [

        'verified' => [
            'title' => 'ناونیشانی ئیمەیڵ گۆڕدرا',
            'body' => 'ناونیشانی ئیمەیڵەکەت بەسەرکەوتوویی بۆ :email گۆڕدرا.',
        ],

    ],

];
