<?php

return [

    'title' => 'Zwei-Faktor-Authentifizierung (2FA) einrichten',

    'heading' => 'Zwei-Faktor-Authentifizierung einrichten',

    'subheading' => '2FA fügt eine zusätzliche Sicherheitsebene zu Ihrem Konto hinzu, indem eine zweite Form der Verifizierung bei der Anmeldung erforderlich ist.',

    'actions' => [

        'continue' => [
            'label' => 'Fortfahren',
        ],

    ],

];
