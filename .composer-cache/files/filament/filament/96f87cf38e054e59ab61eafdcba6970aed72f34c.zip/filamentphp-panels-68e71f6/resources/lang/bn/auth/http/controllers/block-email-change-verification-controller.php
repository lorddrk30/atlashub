<?php

return [

    'notifications' => [

        'email_change_blocked' => [
            'title' => 'ইমেইল ঠিকানা পরিবর্তন ব্লক করা হয়েছে',
            'body' => 'আপনার ইমেইল ঠিকানা পরিবর্তন ব্লক করা হয়েছে।',
        ],

    ],

];
