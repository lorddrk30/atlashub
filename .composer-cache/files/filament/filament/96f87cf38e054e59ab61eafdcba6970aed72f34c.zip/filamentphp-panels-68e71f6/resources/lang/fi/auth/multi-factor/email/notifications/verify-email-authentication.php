<?php

return [

    'subject' => 'Kirjautumiskoodisi',

    'lines' => [
        'Kirjautumiskoodisi on :code',
        'Koodi vanhenee minuutissa.|Koodi vanhenee :minutes minuutissa.',
    ],

];
