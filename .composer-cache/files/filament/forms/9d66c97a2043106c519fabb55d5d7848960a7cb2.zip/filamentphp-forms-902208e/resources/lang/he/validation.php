<?php

return [

    'distinct' => [
        'must_be_selected' => 'יש לבחור לפחות שדה :attribute אחד.',
        'only_one_must_be_selected' => 'יש לבחור שדה :attribute אחד בלבד.',
    ],

];
