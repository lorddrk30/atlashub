<?php

return [

    'distinct' => [
        'must_be_selected' => '至少必須選擇一個 :attribute 欄位。',
        'only_one_must_be_selected' => '只能選擇一個 :attribute 欄位。',
    ],

];
