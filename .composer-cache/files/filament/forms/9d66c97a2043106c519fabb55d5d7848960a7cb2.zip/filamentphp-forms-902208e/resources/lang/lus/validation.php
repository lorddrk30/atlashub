<?php

return [

    'distinct' => [
        'must_be_selected' => ':attribute pakhat tal select tur.',
        'only_one_must_be_selected' => ':attribute pakhat chiah select theih.',
    ],

];
