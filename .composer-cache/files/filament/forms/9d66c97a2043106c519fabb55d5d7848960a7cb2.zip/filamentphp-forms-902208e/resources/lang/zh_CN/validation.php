<?php

return [

    'distinct' => [
        'must_be_selected' => '至少必须选择一个 :attribute 字段。',
        'only_one_must_be_selected' => '只能选择一个 :attribute 字段。',
    ],

];
