<?php

return [

    'distinct' => [
        'must_be_selected' => 'Барем едно поле :attribute мора да биде избрано.',
        'only_one_must_be_selected' => 'Само едно поле :attribute мора да биде избрано.',
    ],

];
