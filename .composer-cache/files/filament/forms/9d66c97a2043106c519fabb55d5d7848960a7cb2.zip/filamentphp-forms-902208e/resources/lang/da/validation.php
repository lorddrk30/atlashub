<?php

return [

    'distinct' => [
        'must_be_selected' => 'Mindst ét :attribute felt skal være valgt.',
        'only_one_must_be_selected' => 'Der må kun vælges ét :attribute felt.',
    ],

];
