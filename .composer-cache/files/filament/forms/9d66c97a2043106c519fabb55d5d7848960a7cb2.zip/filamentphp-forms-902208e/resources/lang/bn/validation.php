<?php

return [

    'distinct' => [
        'must_be_selected' => 'অন্তত একটি :attribute ক্ষেত্র নির্বাচিত হতে হবে।',
        'only_one_must_be_selected' => 'শুধুমাত্র একটি :attribute ক্ষেত্র নির্বাচিত হতে হবে।',
    ],

];
