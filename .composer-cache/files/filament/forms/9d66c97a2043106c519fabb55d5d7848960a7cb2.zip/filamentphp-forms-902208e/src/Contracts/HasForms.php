<?php

namespace Filament\Forms\Contracts;

use Filament\Schemas\Contracts\HasSchemas;

interface HasForms extends HasSchemas {}
