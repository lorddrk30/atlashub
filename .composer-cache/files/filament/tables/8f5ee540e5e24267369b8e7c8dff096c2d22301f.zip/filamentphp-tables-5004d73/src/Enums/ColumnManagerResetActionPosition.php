<?php

namespace Filament\Tables\Enums;

enum ColumnManagerResetActionPosition
{
    case Header;

    case Footer;
}
