<?php

namespace Filament\Tables\Filters\QueryBuilder\Constraints\BooleanConstraint\Operators;

class IsTrueOperator extends \Filament\QueryBuilder\Constraints\BooleanConstraint\Operators\IsTrueOperator {}
