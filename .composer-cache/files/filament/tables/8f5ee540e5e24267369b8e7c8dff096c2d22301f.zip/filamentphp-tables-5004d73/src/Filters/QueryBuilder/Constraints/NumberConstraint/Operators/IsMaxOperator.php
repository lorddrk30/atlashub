<?php

namespace Filament\Tables\Filters\QueryBuilder\Constraints\NumberConstraint\Operators;

class IsMaxOperator extends \Filament\QueryBuilder\Constraints\NumberConstraint\Operators\IsMaxOperator {}
