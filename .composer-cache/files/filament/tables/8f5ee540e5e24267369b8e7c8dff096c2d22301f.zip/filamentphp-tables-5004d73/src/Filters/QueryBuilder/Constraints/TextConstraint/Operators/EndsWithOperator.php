<?php

namespace Filament\Tables\Filters\QueryBuilder\Constraints\TextConstraint\Operators;

class EndsWithOperator extends \Filament\QueryBuilder\Constraints\TextConstraint\Operators\EndsWithOperator {}
