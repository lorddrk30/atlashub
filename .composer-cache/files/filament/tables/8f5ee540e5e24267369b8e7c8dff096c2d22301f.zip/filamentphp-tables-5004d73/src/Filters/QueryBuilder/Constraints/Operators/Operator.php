<?php

namespace Filament\Tables\Filters\QueryBuilder\Constraints\Operators;

class Operator extends \Filament\QueryBuilder\Constraints\Operators\Operator {}
