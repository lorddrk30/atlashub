<?php

namespace Filament\Tables\Filters\QueryBuilder\Constraints\RelationshipConstraint\Operators;

class IsRelatedToOperator extends \Filament\QueryBuilder\Constraints\RelationshipConstraint\Operators\IsRelatedToOperator {}
