<?php

namespace Filament\Tables\Filters\QueryBuilder\Constraints;

class TextConstraint extends \Filament\QueryBuilder\Constraints\TextConstraint {}
