<?php

namespace Filament\Tables\Filters\QueryBuilder\Constraints\RelationshipConstraint\Operators;

class HasMaxOperator extends \Filament\QueryBuilder\Constraints\RelationshipConstraint\Operators\HasMaxOperator {}
