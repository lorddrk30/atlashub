<?php

namespace Filament\Tables\Filters\QueryBuilder\Constraints\RelationshipConstraint\Operators;

class EqualsOperator extends \Filament\QueryBuilder\Constraints\RelationshipConstraint\Operators\EqualsOperator {}
