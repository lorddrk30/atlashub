<?php

namespace Filament\Tables\Filters\QueryBuilder\Constraints\NumberConstraint\Operators;

class EqualsOperator extends \Filament\QueryBuilder\Constraints\NumberConstraint\Operators\EqualsOperator {}
