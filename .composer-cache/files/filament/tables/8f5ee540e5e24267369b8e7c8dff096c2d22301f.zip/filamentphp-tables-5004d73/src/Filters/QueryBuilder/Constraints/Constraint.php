<?php

namespace Filament\Tables\Filters\QueryBuilder\Constraints;

class Constraint extends \Filament\QueryBuilder\Constraints\Constraint {}
