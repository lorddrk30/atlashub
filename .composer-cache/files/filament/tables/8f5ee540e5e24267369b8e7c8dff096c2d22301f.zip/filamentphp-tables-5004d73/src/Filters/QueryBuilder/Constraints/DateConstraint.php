<?php

namespace Filament\Tables\Filters\QueryBuilder\Constraints;

class DateConstraint extends \Filament\QueryBuilder\Constraints\DateConstraint {}
