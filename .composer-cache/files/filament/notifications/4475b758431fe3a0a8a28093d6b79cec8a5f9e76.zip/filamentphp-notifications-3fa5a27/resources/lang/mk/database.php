<?php

return [

    'modal' => [

        'heading' => 'Известувања',

        'actions' => [

            'clear' => [
                'label' => 'Исчисти',
            ],

            'mark_all_as_read' => [
                'label' => 'Означи сите како прочитани',
            ],

        ],

        'empty' => [
            'heading' => 'Нема известувања',
            'description' => 'Ве молиме проверете повторно подоцна.',
        ],

    ],

];
