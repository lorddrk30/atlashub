<?php

return [

    'modal' => [

        'heading' => 'Обавештења',

        'actions' => [

            'clear' => [
                'label' => 'Очисти',
            ],

            'mark_all_as_read' => [
                'label' => 'Означи све као прочитано',
            ],

        ],

        'empty' => [
            'heading' => 'Без обавештења',
            'description' => 'Молим вас, проверите поново касније.',
        ],

    ],

];
