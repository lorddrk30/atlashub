<?php

return [

    'single' => [

        'label' => '表示',

        'modal' => [

            'heading' => ':label 表示',

            'actions' => [

                'close' => [
                    'label' => '閉じる',
                ],

            ],

        ],

    ],

];
