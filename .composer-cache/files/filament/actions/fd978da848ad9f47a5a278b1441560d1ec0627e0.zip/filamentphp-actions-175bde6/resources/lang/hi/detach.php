<?php

return [

    'single' => [

        'label' => 'अलग करें',

        'modal' => [

            'heading' => ':label अलग करें',

            'actions' => [

                'detach' => [
                    'label' => 'अलग करें',
                ],

            ],

        ],

        'notifications' => [

            'detached' => [
                'title' => 'अलग हो गया',
            ],

        ],

    ],

    'multiple' => [

        'label' => 'चयनित अलग करे',

        'modal' => [

            'heading' => 'चयनित :label अलग करे',

            'actions' => [

                'detach' => [
                    'label' => 'चयनित अलग करे',
                ],

            ],

        ],

        'notifications' => [

            'detached' => [
                'title' => 'अलग हो गए',
            ],

        ],

    ],

];
