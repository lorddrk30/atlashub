<?php

return [

    'single' => [

        'label' => 'Vedi',

        'modal' => [

            'heading' => 'Vedi :label',

            'actions' => [

                'close' => [
                    'label' => 'Chiudi',
                ],

            ],

        ],

    ],

];
