<?php

return [

    'single' => [

        'label' => 'ផ្ដាច់',

        'modal' => [

            'heading' => 'ផ្ដាច់ :label',

            'actions' => [

                'detach' => [
                    'label' => 'ផ្ដាច់',
                ],

            ],

        ],

        'notifications' => [

            'detached' => [
                'title' => 'បានផ្ដាច់',
            ],

        ],

    ],

    'multiple' => [

        'label' => 'ផ្ដាច់នៃការជ្រើសរើស',

        'modal' => [

            'heading' => 'បានផ្ដាច់នៃការជ្រើសរើស :label',

            'actions' => [

                'detach' => [
                    'label' => 'ផ្ដាច់',
                ],

            ],

        ],

        'notifications' => [

            'detached' => [
                'title' => 'បានផ្ដាច់',
            ],

        ],

    ],

];
