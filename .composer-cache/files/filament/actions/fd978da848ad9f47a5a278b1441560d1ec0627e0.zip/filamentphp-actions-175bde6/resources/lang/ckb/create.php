<?php

return [

    'single' => [

        'label' => 'زیادکردنی :label',

        'modal' => [

            'heading' => ':زیادکردنی :label',

            'actions' => [

                'create' => [
                    'label' => 'زیادکردن',
                ],

                'create_another' => [
                    'label' => 'زیادکردن و تۆمارێکی تر',
                ],

            ],

        ],

        'notifications' => [

            'created' => [
                'title' => 'زیادکرا',
            ],

        ],

    ],

];
