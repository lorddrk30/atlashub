<?php

return [

    'single' => [

        'label' => 'Изтрий',

        'modal' => [

            'heading' => 'Изтрий :label',

            'actions' => [

                'delete' => [
                    'label' => 'Изтрий',
                ],

            ],

        ],

        'notifications' => [

            'deleted' => [
                'title' => 'Изтрит',
            ],

        ],

    ],

    'multiple' => [

        'label' => 'Изтрий избраните',

        'modal' => [

            'heading' => 'Изтрий избраните :label',

            'actions' => [

                'delete' => [
                    'label' => 'Изтрий',
                ],

            ],

        ],

        'notifications' => [

            'deleted' => [
                'title' => 'Изтрити',
            ],

        ],

    ],

];
