<?php

return [

    'single' => [

        'label' => 'سڕینەوەی بەزۆر',

        'modal' => [

            'heading' => 'سڕینەوەی بەزۆری :label',

            'actions' => [

                'delete' => [
                    'label' => 'سڕینەوە',
                ],

            ],

        ],

        'notifications' => [

            'deleted' => [
                'title' => 'سڕایەوە',
            ],

        ],

    ],

    'multiple' => [

        'label' => 'سڕینەوەی بەزۆری هەڵبژێردراوەکان',

        'modal' => [

            'heading' => 'سڕینەوەی بەزۆری هەڵبژێردراوەکانی :label',

            'actions' => [

                'delete' => [
                    'label' => 'سڕینەوە',
                ],

            ],

        ],

        'notifications' => [

            'deleted' => [
                'title' => 'سڕایەوە',
            ],

        ],

    ],

];
