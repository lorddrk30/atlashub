<?php

return [

    'single' => [

        'label' => 'Dupliquer',

        'modal' => [

            'heading' => 'Dupliquer :label',

            'actions' => [

                'replicate' => [
                    'label' => 'Dupliquer',
                ],

            ],

        ],

        'notifications' => [

            'replicated' => [
                'title' => 'Enregistrement dupliqué',
            ],

        ],

    ],

];
