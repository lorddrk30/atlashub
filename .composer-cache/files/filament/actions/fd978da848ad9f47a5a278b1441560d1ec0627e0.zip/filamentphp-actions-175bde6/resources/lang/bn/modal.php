<?php

return [

    'confirmation' => 'আপনি কি নিশ্চিত আপনি এটি করতে চান?',

    'actions' => [

        'cancel' => [
            'label' => 'বাতিল করুন',
        ],

        'confirm' => [
            'label' => 'নিশ্চিত করুন',
        ],

        'submit' => [
            'label' => 'জমা দিন',
        ],

    ],

];
