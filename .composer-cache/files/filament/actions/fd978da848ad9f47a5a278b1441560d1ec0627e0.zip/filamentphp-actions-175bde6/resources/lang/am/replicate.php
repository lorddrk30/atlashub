<?php

return [

    'single' => [

        'label' => 'ይድገሙት',
        'modal' => [

            'heading' => ':labelን ይድገሙት',
            'actions' => [

                'replicate' => [

                    'label' => 'ይድገሙት',
                ],
            ],
        ],
        'notifications' => [

            'replicated' => [

                'title' => 'ተደግሟል',
            ],
        ],
    ],
];
