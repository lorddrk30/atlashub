<?php

return [

    'throttled' => [
        'title' => 'Trop de tentatives',
        'body' => 'Veuillez réessayer dans :seconds secondes.',
    ],

];
