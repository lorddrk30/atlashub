<?php

return [

    'single' => [

        'label' => 'پەیوەستکردن',

        'modal' => [

            'heading' => 'پەیوەستکردنی :label',

            'fields' => [

                'record_id' => [
                    'label' => 'تۆمار',
                ],

            ],

            'actions' => [

                'attach' => [
                    'label' => 'لکاندن',
                ],

                'attach_another' => [
                    'label' => 'لکاندن و تۆمارێکی تر',
                ],

            ],

        ],

        'notifications' => [

            'attached' => [
                'title' => 'پەیوەستکرا',
            ],

        ],

    ],

];
