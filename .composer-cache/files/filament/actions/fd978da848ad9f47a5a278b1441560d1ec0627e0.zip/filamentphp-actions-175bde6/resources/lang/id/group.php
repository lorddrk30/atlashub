<?php

return [

    'trigger' => [
        'label' => 'Tindakan',
    ],

];
