<?php

return [

    'confirmation' => 'He thil hi iti duh tak tak em?',

    'actions' => [

        'cancel' => [
            'label' => 'Sûtna',
        ],

        'confirm' => [
            'label' => 'Nemnghehna',
        ],

        'submit' => [
            'label' => 'Theh lûhna',
        ],

    ],

];
