<?php

return [

    'single' => [

        'label' => 'שכפול',

        'modal' => [

            'heading' => 'שכפול :label',

            'actions' => [

                'replicate' => [
                    'label' => 'שכפל',
                ],

            ],

        ],

        'notifications' => [

            'replicated' => [
                'title' => 'שוכפל',
            ],

        ],

    ],

];
