<?php

return [

    'single' => [

        'label' => 'עריכה',

        'modal' => [

            'heading' => 'עריכת :label',

            'actions' => [

                'save' => [
                    'label' => 'שמור שינויים',
                ],

            ],

        ],

        'notifications' => [

            'saved' => [
                'title' => 'נשמר',
            ],

        ],

    ],

];
