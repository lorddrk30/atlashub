<?php

return [

    'throttled' => [
        'title' => 'Չափազանց շատ փորձեր',
        'body' => 'Խնդրում ենք կրկին փորձել :seconds վայրկյան հետո։',
    ],

];
