<?php

return [

    'single' => [

        'label' => 'ለያይ',
        'modal' => [

            'heading' => ':labelን ለያይ',
            'actions' => [

                'detach' => [

                    'label' => 'ለያይ',
                ],
            ],
        ],
        'notifications' => [

            'detached' => [

                'title' => 'ተለያይቶዋል',
            ],
        ],
    ],
    'multiple' => [

        'label' => 'የተመረጡትን ለያይ',
        'modal' => [

            'heading' => 'የተመረጡት :labelን ለያይ',
            'actions' => [

                'detach' => [

                    'label' => 'ለያይ',
                ],
            ],
        ],
        'notifications' => [

            'detached' => [

                'title' => 'ለያይ',
            ],
        ],
    ],
];
