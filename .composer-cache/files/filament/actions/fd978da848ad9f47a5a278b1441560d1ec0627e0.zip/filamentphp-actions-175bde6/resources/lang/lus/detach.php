<?php

return [

    'single' => [

        'label' => 'Thlawnna',

        'modal' => [

            'heading' => ':Label thlawnna',

            'actions' => [

                'detach' => [
                    'label' => 'Thlawnna',
                ],

            ],

        ],

        'notifications' => [

            'detached' => [
                'title' => 'Thlawn a ni e.',
            ],

        ],

    ],

    'multiple' => [

        'label' => 'Thlan ho thlawn thenna',

        'modal' => [

            'heading' => ':Label thlan ho thlawn thenna',

            'actions' => [

                'detach' => [
                    'label' => 'Thlawnna',
                ],

            ],

        ],

        'notifications' => [

            'detached' => [
                'title' => 'Thlawn then a ni e.',
            ],

        ],

    ],

];
