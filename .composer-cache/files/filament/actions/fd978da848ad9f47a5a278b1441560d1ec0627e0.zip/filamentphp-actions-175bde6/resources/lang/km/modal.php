<?php

return [

    'confirmation' => 'តើអ្នកប្រាកដទេថាអ្នកចង់ធ្វើបែបនេះ?',

    'actions' => [

        'cancel' => [
            'label' => 'លុបចោល',
        ],

        'confirm' => [
            'label' => 'យល់ព្រម',
        ],

        'submit' => [
            'label' => 'ស្នើសុំ',
        ],

    ],

];
