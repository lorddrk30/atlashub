<?php

return [

    'throttled' => [
        'title' => 'Tumna a tam lutuk',
        'body' => 'Khawngaihin seconds :seconds hnuah ti nawn leh rawh.',
    ],

];
