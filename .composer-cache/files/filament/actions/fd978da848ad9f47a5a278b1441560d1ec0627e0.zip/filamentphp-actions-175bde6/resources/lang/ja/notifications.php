<?php

return [

    'throttled' => [
        'title' => '試行回数が多すぎます',
        'body' => ':seconds 秒後に再試行してください。',
    ],

];
