<?php

return [

    'throttled' => [
        'title' => 'Too many attempts',
        'body' => 'Please try again in :seconds seconds.',
    ],

];
