<?php

return [

    'single' => [

        'label' => 'دەستکاریکردن',

        'modal' => [

            'heading' => 'دەستکاریکردنی :label',

            'actions' => [

                'save' => [
                    'label' => 'پاشەکەوتکردن',
                ],

            ],

        ],

        'notifications' => [

            'saved' => [
                'title' => 'پاشەکەوتکرا',
            ],

        ],

    ],

];
