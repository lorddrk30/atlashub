<?php

return [

    'single' => [

        'label' => 'የምር አጥፋ',
        'modal' => [

            'heading' => ':labelን የምር አጥፋ',
            'actions' => [

                'delete' => [

                    'label' => 'አጥፋ',
                ],
            ],
        ],
        'notifications' => [

            'deleted' => [

                'title' => 'ጠፍቶዋል',
            ],
        ],
    ],
    'multiple' => [

        'label' => 'የተመረጡትን የምር አጥፋ',
        'modal' => [

            'heading' => 'የተመረጡትን :label የምር አጥፋ',
            'actions' => [

                'delete' => [

                    'label' => 'አጥፋ',
                ],
            ],
        ],
        'notifications' => [

            'deleted' => [

                'title' => 'ጠፍቶዋል',
            ],
        ],
    ],
];
