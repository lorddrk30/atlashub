<?php

return [

    'throttled' => [
        'title' => 'Per daug bandymų',
        'body' => 'Prašome bandyti dar kartą po :seconds sekundžių.',
    ],

];
