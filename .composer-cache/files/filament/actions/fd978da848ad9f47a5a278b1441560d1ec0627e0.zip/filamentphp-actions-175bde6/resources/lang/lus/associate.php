<?php

return [

    'single' => [

        'label' => 'Inzawmna',

        'modal' => [

            'heading' => ':Label inzawmna',

            'fields' => [

                'record_id' => [
                    'label' => 'Record',
                ],

            ],

            'actions' => [

                'associate' => [
                    'label' => 'Inzawmna',
                ],

                'associate_another' => [
                    'label' => 'Pakhat zawm a adang zawm lehna',
                ],

            ],

        ],

        'notifications' => [

            'associated' => [
                'title' => 'A inzawm khâwm e.',
            ],

        ],

    ],

];
