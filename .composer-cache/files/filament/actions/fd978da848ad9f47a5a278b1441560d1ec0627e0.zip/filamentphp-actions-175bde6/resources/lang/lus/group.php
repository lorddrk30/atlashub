<?php

return [

    'trigger' => [
        'label' => 'Thiltihna',
    ],

];
