<?php

return [

    'single' => [

        'label' => 'አጣምር',
        'modal' => [

            'heading' => ':labelን አጣምር',
            'fields' => [

                'record_id' => [

                    'label' => 'ሪከርድ',
                ],
            ],
            'actions' => [

                'associate' => [

                    'label' => 'አጣምር',

                ],
                'associate_another' => [

                    'label' => 'አጣምር & ሌላ አጣምር',
                ],
            ],
        ],
        'notifications' => [

            'associated' => [

                'title' => 'ተጣምሮዋል',
            ],
        ],
    ],
];
