<?php

return [

    'single' => [

        'label' => 'Replicar',

        'modal' => [

            'heading' => 'Replicar :label',

            'actions' => [

                'replicate' => [
                    'label' => 'Replicar',
                ],

            ],

        ],

        'notifications' => [

            'replicated' => [
                'title' => 'Registre replicat',
            ],

        ],

    ],

];
