<?php

return [

    'throttled' => [
        'title' => 'অতিরিক্ত চেষ্টা',
        'body' => 'দয়া করে :seconds সেকেন্ড পর আবার চেষ্টা করুন।',
    ],

];
