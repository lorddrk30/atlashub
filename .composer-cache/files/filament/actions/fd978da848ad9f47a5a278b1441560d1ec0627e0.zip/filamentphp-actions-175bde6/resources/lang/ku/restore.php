<?php

return [

    'single' => [

        'label' => 'گێڕانەوە',

        'modal' => [

            'heading' => 'گێڕانەوەی :label',

            'actions' => [

                'restore' => [
                    'label' => 'گێڕانەوە',
                ],

            ],

        ],

        'notifications' => [

            'restored' => [
                'title' => 'گێڕێندرایەوە',
            ],

        ],

    ],

    'multiple' => [

        'label' => 'گێڕانەوەی دیاریکراوەکان',

        'modal' => [

            'heading' => 'گێڕانەوەی دیاریکراوەکانی :label',

            'actions' => [

                'restore' => [
                    'label' => 'گێڕانەوە',
                ],

            ],

        ],

        'notifications' => [

            'restored' => [
                'title' => 'گێڕێندرایەوە',
            ],

        ],

    ],

];
