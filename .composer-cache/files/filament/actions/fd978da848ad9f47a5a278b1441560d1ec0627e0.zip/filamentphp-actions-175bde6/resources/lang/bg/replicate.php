<?php

return [

    'single' => [

        'label' => 'Клонирай',

        'modal' => [

            'heading' => 'Клонирай :label',

            'actions' => [

                'replicate' => [
                    'label' => 'Клонирай',
                ],

            ],

        ],

        'notifications' => [

            'replicated' => [
                'title' => 'Клониран',
            ],

        ],

    ],

];
