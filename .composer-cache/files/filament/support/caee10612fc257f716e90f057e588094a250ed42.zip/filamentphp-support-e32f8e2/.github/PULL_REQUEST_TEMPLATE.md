Please do not submit any Pull Requests here. They will be closed.
---

Please submit your PR here instead:
https://github.com/filamentphp/filament

This repository is what we call a "subtree split": a read-only subset of that main repository.
We're looking forward to your PR there!
