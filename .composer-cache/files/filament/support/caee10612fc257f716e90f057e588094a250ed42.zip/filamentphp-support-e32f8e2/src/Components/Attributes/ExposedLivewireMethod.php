<?php

namespace Filament\Support\Components\Attributes;

use Attribute;

#[Attribute(Attribute::TARGET_METHOD)]
class ExposedLivewireMethod {}
