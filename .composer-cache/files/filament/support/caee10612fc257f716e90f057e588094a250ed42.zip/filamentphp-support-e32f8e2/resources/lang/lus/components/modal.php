<?php

return [

    'actions' => [

        'close' => [
            'label' => 'Khârna',
        ],

    ],

];
