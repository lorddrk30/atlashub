<?php

return [

    'messages' => [
        'uploading_file' => 'Се прикачува датотека...',
    ],

];
