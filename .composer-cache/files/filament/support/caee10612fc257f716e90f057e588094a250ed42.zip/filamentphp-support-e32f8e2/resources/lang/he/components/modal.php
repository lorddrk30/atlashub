<?php

return [

    'actions' => [

        'close' => [
            'label' => 'סגור',
        ],

    ],

];
