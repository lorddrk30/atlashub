<?php

return [

    'messages' => [
        'copied' => 'Kopierades',
    ],

];
