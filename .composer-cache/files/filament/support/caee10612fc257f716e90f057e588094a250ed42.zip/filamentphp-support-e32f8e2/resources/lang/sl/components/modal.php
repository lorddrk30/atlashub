<?php

return [

    'actions' => [

        'close' => [
            'label' => 'Zapri',
        ],

    ],

];
