<?php

return [

    'messages' => [
        'uploading_file' => 'Nalaganje datoteke...',
    ],

];
