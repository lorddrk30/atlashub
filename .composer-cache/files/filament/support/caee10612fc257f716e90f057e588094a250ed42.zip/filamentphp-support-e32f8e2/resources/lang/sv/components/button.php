<?php

return [

    'messages' => [
        'uploading_file' => 'Laddar upp fil...',
    ],

];
