<x-filament::section
    :attributes="\Filament\Support\prepare_inherited_attributes($attributes)"
>
    {{ $slot }}
</x-filament::section>
