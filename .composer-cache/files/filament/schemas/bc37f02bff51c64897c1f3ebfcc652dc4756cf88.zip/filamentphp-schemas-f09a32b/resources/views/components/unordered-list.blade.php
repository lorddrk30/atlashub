<ul
    {{
        $getExtraAttributeBag()
            ->grid($getColumns(), \Filament\Support\Enums\GridDirection::Column)
            ->class([
                'fi-sc-unordered-list',
                (($size = $getSize()) instanceof \Filament\Support\Enums\TextSize) ? "fi-size-{$size->value}" : $size,
            ])
    }}
>
    @foreach ($getChildSchema()->getComponents() as $schemaComponent)
        <li>
            {{ $schemaComponent }}
        </li>
    @endforeach
</ul>
