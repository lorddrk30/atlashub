<?php

return [

    'wizard' => [

        'actions' => [

            'previous_step' => [
                'label' => 'پێشتر',
            ],

            'next_step' => [
                'label' => 'دواتر',
            ],

        ],

    ],

];
