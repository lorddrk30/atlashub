<?php

return [

    'wizard' => [

        'actions' => [

            'previous_step' => [
                'label' => 'Atgal',
            ],

            'next_step' => [
                'label' => 'Pirmyn',
            ],

        ],

    ],

];
