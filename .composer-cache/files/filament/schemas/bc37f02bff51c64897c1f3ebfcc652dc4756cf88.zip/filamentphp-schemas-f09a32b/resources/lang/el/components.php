<?php

return [

    'wizard' => [

        'actions' => [

            'previous_step' => [
                'label' => 'Πίσω',
            ],

            'next_step' => [
                'label' => 'Επόμενο',
            ],

        ],

    ],

];
