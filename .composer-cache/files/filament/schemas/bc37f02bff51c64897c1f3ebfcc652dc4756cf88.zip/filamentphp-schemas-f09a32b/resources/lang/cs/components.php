<?php

return [

    'wizard' => [

        'actions' => [

            'previous_step' => [
                'label' => 'Zpět',
            ],

            'next_step' => [
                'label' => 'Další',
            ],

        ],

    ],

];
