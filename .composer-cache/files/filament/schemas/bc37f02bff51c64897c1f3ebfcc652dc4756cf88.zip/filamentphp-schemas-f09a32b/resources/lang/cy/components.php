<?php

return [

    'wizard' => [

        'actions' => [

            'previous_step' => [
                'label' => 'Yn ôl',
            ],

            'next_step' => [
                'label' => 'Nesaf',
            ],

        ],

    ],

];
