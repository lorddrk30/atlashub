<?php

return [

    'wizard' => [

        'actions' => [

            'previous_step' => [
                'label' => 'قبلی',
            ],

            'next_step' => [
                'label' => 'بعدی',
            ],

        ],

    ],

];
