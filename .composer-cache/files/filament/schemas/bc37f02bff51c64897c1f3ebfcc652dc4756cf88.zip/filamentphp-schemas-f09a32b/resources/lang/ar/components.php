<?php

return [

    'wizard' => [

        'actions' => [

            'previous_step' => [
                'label' => 'الخطوة السابقة',
            ],

            'next_step' => [
                'label' => 'الخطوة التالية',
            ],

        ],

    ],

];
