<?php

return [

    'wizard' => [

        'actions' => [

            'previous_step' => [
                'label' => 'Précédent',
            ],

            'next_step' => [
                'label' => 'Suivant',
            ],

        ],

    ],

];
