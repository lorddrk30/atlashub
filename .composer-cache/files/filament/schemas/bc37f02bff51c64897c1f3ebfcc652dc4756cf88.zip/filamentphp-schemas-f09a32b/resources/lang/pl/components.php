<?php

return [

    'wizard' => [

        'actions' => [

            'previous_step' => [
                'label' => 'Poprzedni',
            ],

            'next_step' => [
                'label' => 'Następny',
            ],

        ],

    ],

];
