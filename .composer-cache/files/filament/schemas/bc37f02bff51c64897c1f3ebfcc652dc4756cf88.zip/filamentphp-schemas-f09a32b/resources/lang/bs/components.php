<?php

return [

    'wizard' => [

        'actions' => [

            'previous_step' => [
                'label' => 'Nazad',
            ],

            'next_step' => [
                'label' => 'Dalje',
            ],

        ],

    ],

];
