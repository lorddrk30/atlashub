<?php

return [

    'wizard' => [

        'actions' => [

            'previous_step' => [
                'label' => 'Lêtna',
            ],

            'next_step' => [
                'label' => 'A dawt',
            ],

        ],

    ],

];
