<?php

return [

    'wizard' => [

        'actions' => [

            'previous_step' => [
                'label' => 'Vorige',
            ],

            'next_step' => [
                'label' => 'Volgende',
            ],

        ],

    ],

];
