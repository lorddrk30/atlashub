<?php

return [

    'wizard' => [

        'actions' => [

            'previous_step' => [
                'label' => 'Natrag',
            ],

            'next_step' => [
                'label' => 'Naprijed',
            ],

        ],

    ],

];
