<?php

return [

    'wizard' => [

        'actions' => [

            'previous_step' => [
                'label' => 'הקודם',
            ],

            'next_step' => [
                'label' => 'הבא',
            ],

        ],

    ],

];
